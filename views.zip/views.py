from django.shortcuts import render
import razorpay
from .models import Products,Contact,Order,Users,Latest
from math import ceil
import random
# Create your views here.
def searchMatch(query,item):
   if query in item.product_Name.lower() or query in item.categoty.lower() or query in item.sub_categoty.lower():
      return True
   else:
      return False

def search(request,m):
   query=m
   aprod = []
   catprod = Products.objects.values('categoty', 'id')
   cats = {item['categoty'] for item in catprod}
   for cat in cats:
      prodtemp = Products.objects.filter(categoty=cat)
      prod=[i for i in prodtemp if searchMatch(query,i)]
      n = len(prod)
      nos = n // 4 + ceil((n / 4) - (n // 4))
      if len(prod) != 0:
       aprod.append([prod, range(1, nos), nos])
   params = {'allprod': aprod,"msg":""}
   if len(aprod)==0 or len(query)<4:
         params={"msg":"Sorry, No item,we can add item in future"}
   return render(request, "shop/shop.html", params)
def searchu(request):
 if request.method=="POST":
   query=request.POST.get('search')
   query=query.lower()
   hj="minimal"
   print(query,hj)
   aprod = []
   catprod = Products.objects.values('categoty', 'id')
   cats = {item['categoty'] for item in catprod}
   for cat in cats:
      prodtemp = Products.objects.filter(categoty=cat)
      prod=[i for i in prodtemp if searchMatch(query,i)]
      n = len(prod)
      nos = n // 4 + ceil((n / 4) - (n // 4))
      if len(prod) != 0:
       aprod.append([prod, range(1, nos), nos])
   params = {'allprod': aprod,"msg":""}
   if len(aprod)==0 or len(query)<4:
         params={"msg":"Sorry, No item,we can add item in future"}
   return render(request, "shop/shop.html", params)
def index(request):
    login = 'true'
    aprod = []
    catprod = Latest.objects.values('categoty', 'id')
    cats = {item['categoty'] for item in catprod}
    for cat in cats:
        prod = Latest.objects.filter(categoty=cat)
        n = len(prod)
        nos = n // 4 + ceil((n / 4) - (n // 4))
        aprod.append([prod, range(1, nos), nos])
    params = {'allprod': aprod}
    return render(request,"shop/index.html",params)

def contact(request):
   if request.method=="POST":
      name=request.POST.get('name')
      email = request.POST.get('email')
      mobile = request.POST.get('mob')
      a=int(len(mobile))
      if a<10 or a>10:
         print(len(mobile))
         return render(request, "shop/contact.html",{"error":"Invalid mobile Number"} )

      msg = request.POST.get('con')
      con=Contact(Name=name,Email=email,Mobile=mobile,Message=msg)
      con.save()
      return render(request, "shop/contact.html", {'error': 'Succesfully send'})
   else:
     return render(request,"shop/contact.html",{'error':'none'})
def tracking(request):
    return render(request,"shop/tracking.html")
def cart(request):
    return render(request,"shop/shop-cart.html")
from django.conf import settings
def checkout(request):
       client=razorpay.Client(auth=(settings.KEY,settings.SECRET))
       pay=client.order.create({"amount":100,'currency':'INR','payment_capture':1})
       print("##########")
       print(pay)
       print("##########")
       return render(request,"shop/checkout.html",pay)
def product(request,id):
   myid=id
   products=Products.objects.filter(id=myid)
   return render(request,"shop/product-details.html",{'product':products[0]})
def productss(request,id):
   myid=id
   products=Latest.objects.filter(id=myid)
   return render(request,"shop/product-details.html",{'product':products[0]})
def shop(request):
    login = 'true'
    aprod = []
    catprod = Products.objects.values('categoty', 'id')
    cats = {item['categoty'] for item in catprod}
    for cat in cats:
        prod = Products.objects.filter(categoty=cat)
        n = len(prod)
        nos = n // 4 + ceil((n / 4) - (n // 4))
        aprod.append([prod, range(1, nos), nos])
    params = {'allprod': aprod}
    products=Products.objects.filter(categoty='Tshirt')
    k=0
    for i in products:
         if str(i.product_image_red) != "null":
             k=1
    if k==0:
        return render(request,"shop/shop.html",params)
    else:
       print(products[0].product_imag_red)
thanks=1
def orderNow(request):
   if request.method == 'POST':
      t=0
      fname=request.POST.get('fname')
      lname = request.POST.get('lname')
      name=fname+lname
      email = request.POST.get('email')
      mobile = request.POST.get('mobile')
      address = request.POST.get('address')
      city = request.POST.get('city')
      state = request.POST.get('state')
      zip = request.POST.get('zip')
      items=request.POST.get('items')
      f=items.split("{<>}")
      print(fname,lname,email,mobile,address,city,state,zip,items)
      if items!='':
       for i in f:
         if i !="":
          opp=i.split("{}")
          print(opp)
          order=Order(Name=name,Email=email,Mobile=mobile,Address=address,City=city,State=state,Zip=zip,Orders_name=opp[0],Orders_quantity=opp[1],Orders_price=opp[2],Orders_size=opp[3],Orders_img=opp[4])
          order.save()
   
       return render(request, "shop/confirmation.html")
       request.method ='GET'
      if items!='' and thanks % 2 != 0:
         return render(request,"shop/index.html")
      else:
         return render(request,"shop/index.html")
   else:
      return render(request, "shop/index.html")
def order(request):
 if request.method == 'POST':
   email = request.POST.get('email')
   print(email)
   products=Order.objects.filter(Email=email)
   a=[]
   sk={}
   if len(products)<0:
     msg='none'
   else:
      msg='true'
      for items in products:
           a.append([items.Orders_name,items.Orders_price ,items.Orders_size,items.order_Description,items.orderid,items.Orders_img])
      a.reverse()
   return render(request, "shop/order.html",{'product':a,'msg':msg})
def delete(request,id):
   myid=id
   products=Order.objects.filter(orderid=myid)
   products[0].delete()
   return render(request, "shop/index.html")